# This is a script to take the second line of a pdb file
# should be the AUTHOR field.
echo -n $1 " " 
head -n 2 $1 | tail -n 1

