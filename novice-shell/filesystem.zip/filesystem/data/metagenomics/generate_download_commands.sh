
# process datasetlist to produce command lines to download first five datasets from MG-RAST
echo Generating download-volta-data.sh
cat datasetlist.csv |grep ^4 | awk '{print "curl http://api.metagenomics.anl.gov/download/mgm" $1 "?file=050.1 > " $2 ".fasta" }' | head -n 5 > download-volta-data.sh
