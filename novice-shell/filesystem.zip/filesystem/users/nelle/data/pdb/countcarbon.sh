# Count the number of Carbons in the structural formulaw
echo -n $1 " "  
grep -w C $1 | wc -l 



